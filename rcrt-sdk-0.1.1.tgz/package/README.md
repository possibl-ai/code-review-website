# `@rcrt/sdk`

> The RCRT Consumer SDK — the primary way consumer apps connect to + build on the RCRT platform.

[![CI](https://github.com/possibl-ai/rcrt-platform/actions/workflows/sdk-build.yml/badge.svg)](https://github.com/possibl-ai/rcrt-platform/actions/workflows/sdk-build.yml)

## Install

```bash
# Internal (Artifact Registry npm) — configure ~/.npmrc first:
# @rcrt:registry=https://australia-southeast1-npm.pkg.dev/possibl-rcrt-au-dev-498105/rcrt-npm/
pnpm add @rcrt/sdk
```

## Quickstart

```ts
import { createClient, passwordTokenProvider } from '@rcrt/sdk';

const baseURL = 'https://api.platform-dev.rcrt.cloud';

const client = createClient({
  baseURL,
  // A user: email + password against POST /v1/auth/login. The provider signs in
  // on first use and again as the ~8h token nears expiry (there is no refresh
  // endpoint). For a service, use staticToken('tk_...' | 'cs_...') instead.
  tokenProvider: passwordTokenProvider({
    baseURL,
    email: process.env.RCRT_EMAIL!,
    password: process.env.RCRT_PASSWORD!,
  }),
  // Required for every tenant-scoped route. Without it you get a 401 that is
  // NOT a credential problem — see docs/sdk/03_AUTH_FLOW.md#workspace-selection.
  tenantId: process.env.RCRT_TENANT_ID!,
});

// Create a breadcrumb
const crumb = await client.breadcrumbs.create({
  name: 'kb-react-hooks',
  content: { body: 'useEffect runs after render...' },
  tags: ['interpret:knowledge'],
});

// Stream chat completions
for await (const event of client.chat.stream('sess-1')) {
  if (event.type === 'agent.message') console.log(event.data);
}
```

## Modules

| Module | Surface |
|--------|---------|
| `client.breadcrumbs` | CRUD + semantic search |
| `client.chat` | Send + stream chat completions (SSE) |
| `client.sessions` | Multi-agent session participants |
| `client.events` | Platform events stream (SSE) |
| `client.organizations` | Orgs + members + tenants |
| `client.tenants` | Tenant API keys + usage |
| `client.billing` | Subscription + checkout |
| `client.files` | Upload + download |
| `client.bulk` | Bulk uploads (NDJSON → SSE) + CDC |

## Error handling

```ts
import { RcrtError, SdkError } from '@rcrt/sdk';

try {
  await client.breadcrumbs.create({ ... });
} catch (e) {
  if (e instanceof RcrtError) {
    console.error(e.code, e.message, e.requestId); // server error
    if (e.retryable) /* retry budget exhausted */
  } else if (e instanceof SdkError) {
    console.error(e.code, e.message); // client-side error
  }
}
```

## Docs

- [Quickstart](../../docs/sdk/01_CONSUMER_QUICKSTART.md)
- [API Reference](../../docs/sdk/02_API_REFERENCE.md)
- [Auth Flow](../../docs/sdk/03_AUTH_FLOW.md)
- [Error Handling](../../docs/sdk/04_ERROR_HANDLING.md)
- [SSE Streams](../../docs/sdk/05_SSE_STREAMS.md)
- [Bulk + CDC](../../docs/sdk/06_BULK_AND_CDC.md)
- [Release Runbook](../../docs/sdk/RELEASE_RUNBOOK.md)

## License

Apache-2.0
