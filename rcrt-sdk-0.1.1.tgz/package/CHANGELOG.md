# Changelog

All notable changes to `@rcrt/sdk` are documented here. The format is based on
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed
- Auth: Firebase is no longer an authentication path. `passwordTokenProvider`
  (email + password against `POST /v1/auth/login`, re-signing in as the ~8h
  token nears expiry) replaces it for a user identity; `staticToken` remains
  for a `tk_*` / `cs_*` key. See
  `docs/findings/17_SELF_HOSTED_PASSWORD_AUTH.md`.

### Deprecated
- `firebaseTokenProvider` is still exported but throws
  `SdkError('AUTH_FIREBASE_REMOVED')`. It was kept as a loud stub rather than
  deleted because the failure it replaces was silent: a Firebase ID token is a
  real, valid JWT, so the old provider handed the gateway a well-formed
  credential it cannot verify and the caller saw a `401` that looked like bad
  credentials.

## [0.1.0] - 2026-07-22

### Added
- Initial release of `@rcrt/sdk` — the RCRT Consumer SDK.
- `createClient(options)` with 9 API modules: `breadcrumbs`, `chat`,
  `sessions`, `events`, `organizations`, `tenants`, `billing`, `files`,
  `bulk`.
- Auth: `firebaseTokenProvider`, `staticToken`, `cachedTokenProvider` with
  auto-refresh on every request.
- Typed errors: `RcrtError` (parses the structured
  `{error:{code,message,retryable,cause}}` envelope) + `SdkError`;
  correlation via `X-Request-Id` + `X-Trace-Id`.
- SSE: `openSSE` async-iterator + `openSSEStream` for chat/events/bulk.
- Retry: `withRetry` with exponential backoff + full jitter, honors
  `Retry-After` + `AbortSignal`.
- Telemetry: pluggable `ILogger` + `IOtelTracer`; generates `request_id` +
  `traceparent` for client/server log correlation.
- Generated types via `openapi-typescript` v7 (types-only, no full codegen).
- OpenAPI 3.1 spec at `docs/api/openapi.yaml` (the single source of truth).
- CI: `sdk-build.yml` (lint + type-check + test + build + codegen check).
- Release: `sdk-release.yml` (manual dispatch, internal AR npm + GitHub
  Releases).
- Consumer docs: quickstart, API reference, auth flow, error handling, SSE,
  bulk/CDC, release runbooks.

[Unreleased]: https://github.com/possibl-ai/rcrt-platform/compare/sdk-v0.1.0...development
[0.1.0]: https://github.com/possibl-ai/rcrt-platform/releases/tag/sdk-v0.1.0
